
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

import nest_asyncio
from langchain_mistralai import ChatMistralAI
from langchain_core.tools import Tool
from langchain_experimental.utilities import PythonREPL
from langchain_community.utilities.wolfram_alpha import WolframAlphaAPIWrapper
from langchain_core.messages import HumanMessage
from langgraph.checkpoint.memory import MemorySaver
from langgraph.prebuilt import create_react_agent

# Apply asyncio
nest_asyncio.apply()

# Initialize memory and model
memory = MemorySaver()
model = ChatMistralAI(model="mistral-large-latest")

# Initialize the Python REPL tool
python_repl = PythonREPL()

# Create the tool to pass to an agent
repl_tool = Tool(
    name="python_repl",
    description="A Python shell. Use this to execute python commands. Input should be a valid python command. If you want to see the output of a value, you should print it out with `print(...)`.",
    func=python_repl.run,
)

# Initialize list of tools
tools = [repl_tool, WolframAlphaAPIWrapper()]

# Create the agent executor using the model and tools
agent_executor = create_react_agent(model, tools, checkpointer=memory)

# Use the agent
config = {"configurable": {"thread_id": "abc123"}}
for chunk in agent_executor.stream(
    {"messages": [HumanMessage(content="hi im bob! and i live in olympia washington")]}, config
):
    print(chunk)
    print("----")
